export interface MenuElementsInterface{
    nombre: string;
    enlace: string;
    icono: string;
}