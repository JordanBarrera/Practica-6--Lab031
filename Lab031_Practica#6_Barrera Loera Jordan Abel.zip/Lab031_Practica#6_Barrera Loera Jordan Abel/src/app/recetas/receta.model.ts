export interface Receta{
    id: number, nombre: string, image: string, ingredientes: string[]   
}